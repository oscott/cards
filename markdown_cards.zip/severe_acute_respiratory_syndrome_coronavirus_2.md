---
title: "Severe acute respiratory syndrome coronavirus 2"
artist: "Oliver Scott"
year: 2020
location: "Offline"
type: "Situation"
format: "Live"
notes: "Timewarp begins"
---
