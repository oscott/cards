---
title: "Reality mapping"
artist: "Kunst Kernewek"
year: 2018
location: "Falmouth Art Gallery"
type: "Situation"
format: "Live"
notes: "Fun Palaces at Falmouth Art Gallery"
---
