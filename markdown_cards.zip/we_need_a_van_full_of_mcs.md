---
title: "we need a van full of mc’s"
artist: "sir os [eu]"
year: 2001
location: "Recording"
type: "Sound"
format: "Vinyl"
notes: "viking-02"
---
