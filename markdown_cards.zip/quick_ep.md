---
title: "quick EP"
artist: "os"
year: 2006
location: "Recording"
type: "Sound"
format: "Vinyl"
notes: "ableton cooledit"
---
