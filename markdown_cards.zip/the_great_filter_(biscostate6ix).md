---
title: "The Great Filter (Biscostate6ix)"
artist: "Oliver Scott"
year: 2018
location: "Falmouth Art Gallery"
type: "Installation"
format: "Box"
notes: "Lemonade Factory at Falmouth Art Gallery"
---
