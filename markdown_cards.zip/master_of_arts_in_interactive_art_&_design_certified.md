---
title: "Master of Arts in Interactive Art & Design certified"
artist: "Falmouth University"
year: 2004
location: ""
type: "MA"
format: "Grade"
notes: "Distinction"
---
