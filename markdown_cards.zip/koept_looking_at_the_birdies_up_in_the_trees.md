---
title: "Koept Looking at the birdies up in the trees"
artist: "os"
year: 2006
location: "KM36"
type: "Performance"
format: "Live"
notes: "Sterling \| KM36 \| Berlin"
---
