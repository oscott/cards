---
title: "The Art Band"
artist: "Koept.net"
year: 2008
location: "Wysing Arts Centre"
type: "Performance"
format: "Live"
notes: "Wysing re-launch \| Wysing Arts Centre \| Cambridge"
---
