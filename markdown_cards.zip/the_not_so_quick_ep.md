---
title: "the not so quick EP"
artist: "os"
year: 2006
location: "Recording"
type: "Sound"
format: "Vinyl"
notes: "inept-13"
---
