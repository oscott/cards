---
title: "Stroke I"
artist: "Oliver Scott"
year: 2015
location: "Offline"
type: "Performance"
format: "Live / MRI"
notes: "Trelisk Hospital"
---
