---
title: "Somewhere in Between"
artist: "Oliver Scott"
year: 2005
location: "Galerie KIT"
type: "Performance"
format: "Live"
notes: "Galerie KIT \| Kunstakademi \| Trondheim / Kyoto"
---
