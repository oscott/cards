---
title: "Kiss Kiss / A Little Bit"
artist: "sir os [eu]"
year: 2002
location: "Mexico Towan"
type: "Performance"
format: "Live"
notes: ""
---
