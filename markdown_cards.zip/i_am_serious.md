---
title: "i am serious"
artist: "sir os [eu]"
year: 2001
location: "Recording"
type: "Sound"
format: "cdr+paper"
notes: "casio cooledit fruityloops cubase acid"
---
