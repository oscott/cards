---
title: "camels tomp"
artist: "captain"
year: 2000
location: "Recording"
type: "Performance"
format: "cdr"
notes: "fruityloops"
---
