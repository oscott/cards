---
title: "SkatePal"
artist: "Oliver Scott"
year: 2019
location: "Falmouth Art Gallery"
type: "Situation"
format: "Live"
notes: "Live 2 way stream for young skaters in Palestine and Cornwall"
---
