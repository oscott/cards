---
title: "trade-secrets.md crptngdata.md grading"
artist: "Oliver Scott"
year: 2017
location: "Falmouth Art Gallery"
type: "Installation"
format: "Box"
notes: "Outspoken / Corrupting Data at Falmouth Art Gallery"
---
