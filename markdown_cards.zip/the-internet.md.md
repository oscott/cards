---
title: "the-internet.md"
artist: "Oliver Scott"
year: 2016
location: "C.a.s.t. (Cornubian Arts & Science Trust)"
type: "Performance"
format: "Live"
notes: "at Cast"
---
