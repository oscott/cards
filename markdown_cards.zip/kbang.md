---
title: "kBang"
artist: "Kunst Kernewek"
year: 2008
location: "The Old Lemonade Factory"
type: "Curated"
format: "Various"
notes: "Kunst Kernewek \| The Old Lemonade Factory \| Falmouth"
---
