---
title: "Motion Flow Visualization"
artist: "Alex Turner"
year: 2023
location: "Falmouth Art Gallery"
type: "Installation"
format: "p5.js"
notes: "Interactive for Line"
---
