---
title: "Cost of nothing x noise at no cost."
artist: "Oliver Scott"
year: 2024
location: "www"
type: "Sound"
format: "Hypertext"
notes: "You must copy and paste this link https://os.koe.pt/024/BZine to avoid me gaining any rich data from you."
---
