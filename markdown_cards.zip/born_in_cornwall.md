---
title: "Born in Cornwall"
artist: "UK. Various"
year: 1979
location: "oliver"
type: "Local"
format: "Performance"
notes: "Live Various 20 year subconscious performance"
---
