---
title: "Koept.net"
artist: "Koept.net"
year: 2002
location: "Public Life"
type: "Performance"
format: "Live"
notes: "Koept.net [inept-06] Launch Party \| Public Life \| London"
---
