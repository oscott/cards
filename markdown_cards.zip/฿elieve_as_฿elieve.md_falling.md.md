---
title: "฿elieve as ฿elieve.md falling.md"
artist: "@Oliver_w_Scott"
year: 2015
location: "Cultshare"
type: "Installation"
format: "Box"
notes: ""
---
