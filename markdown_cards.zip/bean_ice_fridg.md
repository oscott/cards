---
title: "Bean Ice Fridg"
artist: "wooden tit"
year: 2005
location: "Recording"
type: "Sound"
format: "mp3"
notes: "hc117"
---
