---
title: "we are just …"
artist: "fourblacksquares"
year: 2002
location: "Recording"
type: "Sound"
format: "Various"
notes: "reason cooledit"
---
