---
title: "absolutely fuck you"
artist: "oliver"
year: 2000
location: "Recording"
type: "Sound"
format: "cdr"
notes: "cooledit fruityloops cubase acid"
---
