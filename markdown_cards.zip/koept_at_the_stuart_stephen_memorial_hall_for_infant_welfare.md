---
title: "Koept at the Stuart Stephen Memorial Hall for Infant Welfare"
artist: "Kunst Kernewek"
year: 2011
location: "Stuart Stephens Memorial Hall for Infant Wellfare"
type: "Situation"
format: "Live"
notes: "Resound Falmouth 2011 \| Stuart Stephen Memorial Hall for Infant Welfare \| Penryn"
---
