---
title: "plan c"
artist: "sir os [eu] + the koala octet"
year: 2001
location: "Recording"
type: "Sound"
format: "Vinyl"
notes: "inept-05"
---
