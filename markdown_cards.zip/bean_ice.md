---
title: "bean ice"
artist: "wooden tit"
year: 2004
location: "Recording"
type: "Sound"
format: "mp3"
notes: "live"
---
