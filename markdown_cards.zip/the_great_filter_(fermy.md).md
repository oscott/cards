---
title: "The Great Filter (fermy.md)"
artist: "Oliver Scott"
year: 2018
location: "New River Studios"
type: "Performance"
format: "Live"
notes: ""
---
