---
title: "Shadow machine"
artist: "Oliver Scott"
year: 2019
location: "Falmouth Art Gallery"
type: "Installation"
format: "p5.js"
notes: "Shadow puppet corner"
---
