---
title: "Stroke II"
artist: "Oliver Scott"
year: 2021
location: "Offline"
type: "Performance"
format: "Live / MRI"
notes: "Trelisk Hospital"
---
