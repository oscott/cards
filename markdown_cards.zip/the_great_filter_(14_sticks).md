---
title: "The Great Filter (14 Sticks)"
artist: "Oliver Scott"
year: 2018
location: "Recording"
type: "Sound"
format: "mp3"
notes: ""
---
