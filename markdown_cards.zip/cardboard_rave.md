---
title: "Cardboard Rave"
artist: "Koept.net"
year: 2004
location: "Centre for Intellectual Raving & LIETUVA"
type: "Performance"
format: "Live"
notes: "Centre for Intellectual Raving \| Pro-test Lab/ LIETUVA \| Vilnius / Falmouth"
---
