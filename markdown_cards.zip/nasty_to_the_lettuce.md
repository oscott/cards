---
title: "nasty to the lettuce"
artist: "sir os [eu]"
year: 2001
location: "Recording"
type: "Sound"
format: "Vinyl"
notes: ""
---
